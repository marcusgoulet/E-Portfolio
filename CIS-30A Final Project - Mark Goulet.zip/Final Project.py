#Mark Goulet
#CIS-30A
#Finance Tracker

#finance class - making income, expenses, and savings class characteristics
class FinanceTracker:
    def __init__(self):
        self.data = {
            "income": [],
            "expenses": [],
            "savings_goal": 0
        }
        self.intro()

#program intro to prompt when the code is initialized, getting default inputs
    def intro(self):
        print("Welcome to the Personal Finance Tracker!")
        print("You will be prompted to enter your initial financial data.")

        while True:
            source = input("Enter an income source (or 'done' to finish): ")
            if source.lower() == 'done':
                break
            amount = float(input(f"Enter amount for {source}: "))
            self.data["income"].append(f"{source} : {amount}")

        self.data["savings_goal"] = float(input("Enter your savings goal: "))

        while True:
            category = input("Enter an expense category (or 'done' to finish): ")
            if category.lower() == 'done':
                break
            amount = float(input(f"Enter amount for {category}: "))
            self.data["expenses"].append(f"{category} : {amount}")
            self.display_remaining_budget()

        print("Initial financial data setup complete! You can now access the menu.")

#menu function to add income
    def add_income(self, source, amount):
        self.data["income"].append(f"{source} : {amount}")
        print(f"Income added: {source} - ${amount}")


#menu function to add expenses
    def add_expense(self, category, amount):
        self.data["expenses"].append(f"{category} : {amount}")
        print(f"Expense added: {category} - ${amount}")
        self.display_remaining_budget()

#menu function to adjust savings goal
    def set_savings_goal(self, amount):
        self.data["savings_goal"] = amount
        print(f"Savings goal set to ${amount}")

#menu function to display summary
    def display_summary(self):
        total_income = sum(float(item.split(" : ")[1]) for item in self.data["income"])
        total_expenses = sum(float(item.split(" : ")[1]) for item in self.data["expenses"])
        remaining_budget = total_income - total_expenses - self.data["savings_goal"]

        print("\nFinancial Summary:")
        print(f"Total Income : ${total_income}")
        print(f"Total Expenses : ${total_expenses}")
        print(f"Savings Goal : ${self.data['savings_goal']}")
        print(f"Remaining Budget : ${remaining_budget}")

#function to display remaining budget, prompted after new expense is added
    def display_remaining_budget(self):
        total_income = sum(float(item.split(" : ")[1]) for item in self.data["income"])
        total_expenses = sum(float(item.split(" : ")[1]) for item in self.data["expenses"])
        remaining_budget = total_income - total_expenses - self.data["savings_goal"]
        print(f"Updated Remaining Budget : ${remaining_budget}")

#function to save summary to txt file after quiting program
    def save_data(self):
        pad = 20  # Adjust column width for alignment
        try:
            with open("finance_data.txt", "w") as file:
                # Writing Income Section
                file.write("- Income -\n")
                for income in self.data["income"]:
                    category, amount = income.split(" : ")
                    file.write(f"{category:<{pad}}${float(amount):>10.2f}\n")

                # Writing Savings Goal
                file.write("\n- Savings Goal -\n")
                file.write(f"{'Goal':<{pad}}${self.data['savings_goal']:>10.2f}\n")

                # Writing Expenses Section
                file.write("\n- Expenses -\n")
                for expense in self.data["expenses"]:
                    category, amount = expense.split(" : ")
                    file.write(f"{category:<{pad}}${float(amount):>10.2f}\n")

                # Calculating Remaining Balance
                total_income = sum(float(item.split(" : ")[1]) for item in self.data["income"])
                total_expenses = sum(float(item.split(" : ")[1]) for item in self.data["expenses"])
                remaining_balance = total_income - total_expenses - self.data["savings_goal"]

                # Writing Remaining Balance
                file.write("\n- Remaining Balance -\n")
                file.write(f"{'Balance':<{pad}}${remaining_balance:>10.2f}\n")

            print("Data saved successfully.")
        except Exception as e:
            print(f"Error saving data: {e}")

    #main menu, can select from different choices, saves and ends when 5 is selected
    def main_menu(self):
        while True:
            print("\nPersonal Finance Tracker")
            print("1. Add Income")
            print("2. Add Expense")
            print("3. Set Savings Goal")
            print("4. Display Summary")
            print("5. Save & Exit")

            choice = input("Select an option: ")

            if choice == "1":
                source = input("Enter income source: ")
                amount = float(input("Enter income amount: "))
                self.add_income(source, amount)
            elif choice == "2":
                category = input("Enter expense category: ")
                amount = float(input("Enter expense amount: "))
                self.add_expense(category, amount)
            elif choice == "3":
                amount = float(input("Enter savings goal: "))
                self.set_savings_goal(amount)
            elif choice == "4":
                self.display_summary()
            elif choice == "5":
                self.save_data()
                print("Exiting program. Goodbye!")
                break
            else:
                print("Invalid choice. Please try again.")

#where code is run

tracker = FinanceTracker()
tracker.main_menu()
